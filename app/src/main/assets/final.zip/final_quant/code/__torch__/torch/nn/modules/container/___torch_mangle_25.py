class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  __annotations__["1"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  __annotations__["2"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  __annotations__["3"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  __annotations__["4"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  __annotations__["5"] = __torch__.wenet.transformer.decoder_layer.___torch_mangle_24.DecoderLayer
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_25.ModuleList) -> None:
    _0 = uninitialized(None)
    ops.prim.RaiseException("Exception")
    return _0
