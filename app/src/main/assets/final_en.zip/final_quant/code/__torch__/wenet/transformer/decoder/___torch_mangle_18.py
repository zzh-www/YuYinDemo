class BiTransformerDecoder(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  left_decoder : __torch__.wenet.transformer.decoder.___torch_mangle_17.TransformerDecoder
  right_decoder : __torch__.wenet.transformer.decoder.___torch_mangle_17.TransformerDecoder
  def forward(self: __torch__.wenet.transformer.decoder.___torch_mangle_18.BiTransformerDecoder,
    memory: Tensor,
    memory_mask: Tensor,
    ys_in_pad: Tensor,
    ys_in_lens: Tensor,
    r_ys_in_pad: Tensor,
    reverse_weight: float=0.) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = (self.left_decoder).forward(memory, memory_mask, ys_in_pad, ys_in_lens, None, 0., )
    l_x, _1, olens, = _0
    r_x = torch.tensor(0., dtype=None, device=None, requires_grad=False)
    if torch.gt(reverse_weight, 0.):
      _2 = (self.right_decoder).forward(memory, memory_mask, r_ys_in_pad, ys_in_lens, None, 0., )
      r_x1, _3, olens1, = _2
      r_x0, olens0 = r_x1, olens1
    else:
      r_x0, olens0 = r_x, olens
    return (l_x, r_x0, olens0)
