class PositionalEncoding(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  d_model : int
  xscale : float
  max_len : int
  pe : Tensor
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  def forward(self: __torch__.wenet.transformer.embedding.PositionalEncoding,
    x: Tensor,
    offset: int=0) -> Tuple[Tensor, Tensor]:
    _0 = torch.lt(torch.add(offset, torch.size(x, 1)), self.max_len)
    if _0:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _1 = torch.to(self.pe, ops.prim.device(x), None, False, False)
    self.pe = _1
    _2 = torch.slice(self.pe, 0, 0, 9223372036854775807, 1)
    pos_emb = torch.slice(_2, 1, offset, torch.add(offset, torch.size(x, 1)), 1)
    x0 = torch.add(torch.mul(x, self.xscale), pos_emb, alpha=1)
    _3 = ((self.dropout).forward(x0, ), (self.dropout).forward(pos_emb, ))
    return _3
  def position_encoding(self: __torch__.wenet.transformer.embedding.PositionalEncoding,
    offset: int,
    size: int) -> Tensor:
    _4 = torch.lt(torch.add(offset, size), self.max_len)
    if _4:
      pass
    else:
      ops.prim.RaiseException("Exception")
    _5 = self.dropout
    _6 = torch.slice(self.pe, 0, 0, 9223372036854775807, 1)
    _7 = torch.slice(_6, 1, offset, torch.add(offset, size), 1)
    return (_5).forward(_7, )
