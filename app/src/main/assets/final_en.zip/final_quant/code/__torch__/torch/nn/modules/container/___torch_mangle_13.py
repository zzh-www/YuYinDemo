class ModuleList(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  __annotations__["0"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["1"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["2"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["3"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["4"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["5"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["6"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["7"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["8"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["9"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["10"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  __annotations__["11"] = __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer
  def forward(self: __torch__.torch.nn.modules.container.___torch_mangle_13.ModuleList) -> None:
    _0 = uninitialized(None)
    ops.prim.RaiseException("Exception")
    return _0
