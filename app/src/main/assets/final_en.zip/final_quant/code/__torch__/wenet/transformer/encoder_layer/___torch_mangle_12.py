class TransformerEncoderLayer(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  size : int
  normalize_before : bool
  concat_after : bool
  self_attn : __torch__.wenet.transformer.attention.___torch_mangle_10.MultiHeadedAttention
  feed_forward : __torch__.wenet.transformer.positionwise_feed_forward.___torch_mangle_11.PositionwiseFeedForward
  norm1 : __torch__.torch.nn.modules.normalization.LayerNorm
  norm2 : __torch__.torch.nn.modules.normalization.LayerNorm
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  concat_linear : __torch__.torch.nn.quantized.dynamic.modules.linear.Linear
  def forward(self: __torch__.wenet.transformer.encoder_layer.___torch_mangle_12.TransformerEncoderLayer,
    x: Tensor,
    mask: Tensor,
    pos_emb: Tensor,
    mask_pad: Optional[Tensor]=None,
    output_cache: Optional[Tensor]=None,
    cnn_cache: Optional[Tensor]=None) -> Tuple[Tensor, Tensor, Tensor]:
    if self.normalize_before:
      x0 = (self.norm1).forward(x, )
    else:
      x0 = x
    if torch.__is__(output_cache, None):
      x_q, mask0, residual, output_cache0 = x0, mask, x, output_cache
    else:
      output_cache1 = unchecked_cast(Tensor, output_cache)
      _0 = torch.eq(torch.size(output_cache1, 0), torch.size(x0, 0))
      if _0:
        pass
      else:
        ops.prim.RaiseException("Exception")
      _1 = torch.eq(torch.size(output_cache1, 2), self.size)
      if _1:
        pass
      else:
        ops.prim.RaiseException("Exception")
      _2 = torch.lt(torch.size(output_cache1, 1), torch.size(x0, 1))
      if _2:
        pass
      else:
        ops.prim.RaiseException("Exception")
      chunk = torch.sub(torch.size(x0, 1), torch.size(output_cache1, 1))
      _3 = torch.slice(x0, 0, 0, 9223372036854775807, 1)
      _4 = torch.slice(_3, 1, torch.neg(chunk), 9223372036854775807, 1)
      x_q0 = torch.slice(_4, 2, 0, 9223372036854775807, 1)
      _5 = torch.slice(x, 0, 0, 9223372036854775807, 1)
      _6 = torch.slice(_5, 1, torch.neg(chunk), 9223372036854775807, 1)
      residual0 = torch.slice(_6, 2, 0, 9223372036854775807, 1)
      _7 = torch.slice(mask, 0, 0, 9223372036854775807, 1)
      _8 = torch.slice(_7, 1, torch.neg(chunk), 9223372036854775807, 1)
      mask1 = torch.slice(_8, 2, 0, 9223372036854775807, 1)
      x_q, mask0, residual, output_cache0 = x_q0, mask1, residual0, output_cache1
    if self.concat_after:
      _9 = (self.self_attn).forward(x_q, x0, x0, mask0, CONSTANTS.c0, )
      x_concat = torch.cat([x0, _9], -1)
      _10 = (self.concat_linear).forward(x_concat, )
      x1 = torch.add(residual, _10, alpha=1)
    else:
      _11 = self.dropout
      _12 = (self.self_attn).forward(x_q, x0, x0, mask0, CONSTANTS.c0, )
      x2 = torch.add(residual, (_11).forward(_12, ), alpha=1)
      x1 = x2
    _13 = torch.__not__(self.normalize_before)
    if _13:
      x3 = (self.norm1).forward(x1, )
    else:
      x3 = x1
    if self.normalize_before:
      x4 = (self.norm2).forward(x3, )
    else:
      x4 = x3
    _14 = (self.dropout).forward((self.feed_forward).forward(x4, ), )
    x5 = torch.add(x3, _14, alpha=1)
    _15 = torch.__not__(self.normalize_before)
    if _15:
      x6 = (self.norm2).forward(x5, )
    else:
      x6 = x5
    _16 = torch.__isnot__(output_cache0, None)
    if _16:
      output_cache2 = unchecked_cast(Tensor, output_cache0)
      x7 = torch.cat([output_cache2, x6], 1)
    else:
      x7 = x6
    fake_cnn_cache = torch.tensor([0.], dtype=ops.prim.dtype(x7), device=ops.prim.device(x7), requires_grad=False)
    return (x7, mask0, fake_cnn_cache)
