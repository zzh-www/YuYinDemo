def log_softmax(input: Tensor,
    dim: Optional[int]=None,
    _stacklevel: int=3,
    dtype: Optional[int]=None) -> Tensor:
  _0 = __torch__.torch.nn.functional._get_softmax_dim
  if torch.__is__(dim, None):
    dim1 = _0("log_softmax", torch.dim(input), _stacklevel, )
    dim0 = dim1
  else:
    dim0 = unchecked_cast(int, dim)
  if torch.__is__(dtype, None):
    ret0 = torch.log_softmax(input, dim0, None)
    ret = ret0
  else:
    dtype0 = unchecked_cast(int, dtype)
    ret1 = torch.log_softmax(input, dim0, dtype0)
    ret = ret1
  return ret
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  if torch.lt(p, 0.):
    _1 = True
  else:
    _1 = torch.gt(p, 1.)
  if _1:
    ops.prim.RaiseException("Exception")
  else:
    pass
  if inplace:
    _2 = torch.dropout_(input, p, training)
  else:
    _2 = torch.dropout(input, p, training)
  return _2
def layer_norm(input: Tensor,
    normalized_shape: List[int],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _3 = torch.layer_norm(input, normalized_shape, weight, bias, eps, True)
  return _3
def embedding(input: Tensor,
    weight: Tensor,
    padding_idx: Optional[int]=None,
    max_norm: Optional[float]=None,
    norm_type: float=2.,
    scale_grad_by_freq: bool=False,
    sparse: bool=False) -> Tensor:
  if torch.__isnot__(padding_idx, None):
    padding_idx1 = unchecked_cast(int, padding_idx)
    if torch.gt(padding_idx1, 0):
      _4 = torch.lt(padding_idx1, torch.size(weight, 0))
      if _4:
        pass
      else:
        ops.prim.RaiseException("Exception")
      padding_idx2 = padding_idx1
    else:
      if torch.lt(padding_idx1, 0):
        _5 = torch.neg(torch.size(weight, 0))
        if torch.ge(padding_idx1, _5):
          pass
        else:
          ops.prim.RaiseException("Exception")
        padding_idx4 = torch.add(torch.size(weight, 0), padding_idx1)
        padding_idx3 = padding_idx4
      else:
        padding_idx3 = padding_idx1
      padding_idx2 = padding_idx3
    padding_idx0 = padding_idx2
  else:
    padding_idx0 = -1
  if torch.__isnot__(max_norm, None):
    input1 = torch.contiguous(input, memory_format=0)
    input0 = input1
  else:
    input0 = input
  _6 = torch.embedding(weight, input0, padding_idx0, scale_grad_by_freq, sparse)
  return _6
def ctc_loss(log_probs: Tensor,
    targets: Tensor,
    input_lengths: Tensor,
    target_lengths: Tensor,
    blank: int=0,
    reduction: str="mean",
    zero_infinity: bool=False) -> Tensor:
  _7 = __torch__.torch.nn._reduction.get_enum
  _8 = torch.ctc_loss(log_probs, targets, input_lengths, target_lengths, blank, _7(reduction, ), zero_infinity)
  return _8
def kl_div(input: Tensor,
    target: Tensor,
    size_average: Optional[bool]=None,
    reduce: Optional[bool]=None,
    reduction: str="mean",
    log_target: bool=False) -> Tensor:
  _9 = __torch__.torch.nn._reduction.legacy_get_enum
  _10 = "reduction: \'mean\' divides the total loss by both the batch size and the support size.\'batchmean\' divides only by the batch size, and aligns with the KL div math definition.\'mean\' will be changed to behave the same as \'batchmean\' in the next major release."
  _11 = __torch__.torch.nn._reduction.get_enum
  if torch.__isnot__(size_average, None):
    _12, size_average0 = True, unchecked_cast(bool, size_average)
  else:
    _12, size_average0 = torch.__isnot__(reduce, None), size_average
  if _12:
    reduction_enum = _9(size_average0, reduce, True, )
  else:
    if torch.eq(reduction, "mean"):
      torch.warn(_10, 2)
    else:
      pass
    if torch.eq(reduction, "batchmean"):
      reduction_enum0 = _11("sum", )
    else:
      reduction_enum0 = _11(reduction, )
    reduction_enum = reduction_enum0
  reduced = torch.kl_div(input, target, reduction_enum, log_target=log_target)
  if torch.eq(reduction, "batchmean"):
    _13 = torch.ne(torch.dim(input), 0)
  else:
    _13 = False
  if _13:
    reduced1 = torch.div(reduced, (torch.size(input))[0])
    reduced0 = reduced1
  else:
    reduced0 = reduced
  return reduced0
def _get_softmax_dim(name: str,
    ndim: int,
    stacklevel: int) -> int:
  _14 = "Implicit dimension choice for {} has been deprecated. Change the call to include dim=X as an argument."
  torch.warn(torch.format(_14, name), stacklevel)
  if torch.eq(ndim, 0):
    _15 = True
  else:
    _15 = torch.eq(ndim, 1)
  if _15:
    _16 = True
  else:
    _16 = torch.eq(ndim, 3)
  if _16:
    ret = 0
  else:
    ret = 1
  return ret
